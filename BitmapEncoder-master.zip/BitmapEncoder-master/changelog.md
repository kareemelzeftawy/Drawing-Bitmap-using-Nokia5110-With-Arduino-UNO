#2014-08-12
* larger output text area
* upper case output hex value
* bitmap takes the name of the selected file

#2014-08-19
* added radio buttons to choose single or multi-file mode
* added method for handling multiple image files in a single operation
* various tweaks to the interface to accommodate new layout and modes
* minor code cleanup/standardization (access modifiers, getters/setters, etc.)

#2014-08-26
* fixed issue with saved directories for FileChooser that no longer exist