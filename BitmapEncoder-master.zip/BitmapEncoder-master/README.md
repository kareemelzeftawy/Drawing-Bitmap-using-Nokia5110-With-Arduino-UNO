BitmapEncoder
=============

**Encode images to display them on your Gamebuino**

The encoder is programmed using Java 8, so you have to install the Java 8 JRE if you don't already have it.

You can download it here: [Java 8 Download](http://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html)

Once Java is installed, simply double click on BitmapEncoder.jar to run it.
